import { Component } from '@angular/core';

@Component({
  selector: 'app-cuerpo-receta',
  standalone: true,
  imports: [],
  templateUrl: './cuerpo-receta.component.html',
  styleUrl: './cuerpo-receta.component.css'
})
export class CuerpoRecetaComponent {

}
